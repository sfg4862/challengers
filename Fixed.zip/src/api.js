const host = 'https://challengers.o-r.kr/api/';

module.exports = host;