export const API = {
    user: `${process.env.REACT_APP_BASE_URL}/user`,
    items: `${process.env.REACT_APP_BASE_URL}/items`,
    cart: `${process.env.REACT_APP_BASE_URL}/carts`,
    signin: `${process.env.REACT_APP_BASE_URL}/signin`,
    signup: `${process.env.REACT_APP_BASE_URL}/signup`,
};
